package com.example.conversordetemperaturas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{

    Button BC, BF , BK;
    RadioButton RC, RF, RK;
    RadioGroup RG;
    EditText ED1;
    int buttonID  = 0;
    double resultado = 0;
    @Override

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BC = findViewById(R.id.btn_C);BF = findViewById(R.id.btn_F);BK = findViewById(R.id.btn_K);
        RC = findViewById(R.id.RBC);RF = findViewById(R.id.RBF);RK = findViewById(R.id.RBK);
        RG = findViewById(R.id.RBgroup);ED1 = findViewById(R.id.ET1);
    }
       public void converttoC(View view)
       {
            if(buttonID == 2)
            {
               resultado = Double.parseDouble(ED1.getText().toString()) - 273.15;
            }
            else if(buttonID == 3)
            {
                resultado = (Double.parseDouble(ED1.getText().toString()) - 32) * 5/9;
            }
        this.Enviar(resultado, "Cº");
       }
       public void converttoF(View view)
       {
           if(buttonID == 1)
           {
            resultado = Double.parseDouble(ED1.getText().toString()) * 9/5 + 32;
           }
           else if(buttonID == 2)
           {
            resultado = (Double.parseDouble(ED1.getText().toString()) * 1.8) - 459.67;
           }this.Enviar(resultado, "F");
       }

       public void converttoK(View view)
       {
           if(buttonID == 1)
           {
            resultado = Double.parseDouble(ED1.getText().toString()) + 273.15;
           }
           else if(buttonID == 3)
           {
            resultado = (Double.parseDouble(ED1.getText().toString()) + 459.67) / 1.8 ;
           }
        this.Enviar(resultado,"K");
       }
       public void CheckC(View view)
       {
        BK.setEnabled(true);
        BF.setEnabled(true);
        buttonID = 1;
           if(buttonID == 1)
           {
            BC.setEnabled(false);
           }
       }
       public void CheckK(View view)
       {
        BF.setEnabled(true);
        BC.setEnabled(true);
        buttonID = 2;
           if(buttonID == 2)
           {
            BK.setEnabled(false);
           }
       }
       public void CheckF(View view)
       {
        BK.setEnabled(true);
        BC.setEnabled(true);
        buttonID = 3;
           if(buttonID == 3)
           {
            BF.setEnabled(false);
           }
       }

    public void Enviar(double resultado, String unidade)
    {
        Intent Tela_resultado = new Intent(MainActivity.this, Resultado.class);
        Bundle Res = new Bundle();
        Res.putDouble("result",resultado);
        Res.putString("unit", unidade);
        Tela_resultado.putExtras(Res);
        startActivity(Tela_resultado);
    }
}
