package com.example.conversordetemperaturas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.text.NumberFormat;

public class Resultado extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado);
        Intent Rec = getIntent();
        Bundle conjunto = Rec.getExtras();
        Double result = conjunto.getDouble("result");
        String unidade = conjunto.getString("unit");
        TextView TV_result = findViewById(R.id.TV_result);
        NumberFormat DF1 = NumberFormat.getInstance();
        DF1.setMaximumFractionDigits(2);
        TV_result.setText("Temperatura convertida: \n \n " + DF1.format(result) + "" +unidade);
    }

    public void Back(View view)
    {
        Intent voltar = new Intent(Resultado.this, MainActivity.class);
        startActivity(voltar);
    }
}
